const express = require("express");
const bodyParser = require("body-parser");
const mysql = require("mysql");
var session = require("express-session");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const fileUpload = require("express-fileupload");
var path = require("path");
var unique = require("array-unique");
const app = express();
const util = require("util");
var cookieParser = require("cookie-parser");
var async = require("async");
var cors = require("cors");
const pad = require("pad");
const nodemailer = require("nodemailer");
var isNullOrEmpty = require("is-null-or-empty");
const https = require("https");
const crypto = require("crypto");
const compress_images = require("compress-images");

const routes = require("express").Router();

const dbConnection = mysql.createPool({
  connectionLimit: 10,
  host: "localhost",
  user: "root",
  password: "",
  database: "microfin_ecommerce_3",
  dateStrings: true,
});

dbConnection.getConnection((err) => {
  if (err) {
    throw err;
  }
  console.log("Connected to database...");
});

const query = util.promisify(dbConnection.query).bind(dbConnection);


routes.get("/", (req, res) => {
  res.status(200).json({ message: "api call success 1 !!" });
});

routes.get("/check", (req, res) => {
  res.status(200).json({ message: "api call success - check 1 !!" });
});

/*
 * E-COURIER API | Turzo Ahsan Sami | 20 August 2020
 */

routes.get("/getSaleProductCustomerDetails/:sales_id", async (req, res) => {
  const { sales_id } = req.params;
  try {
    const sales_product_customer_details = await query(`
        SELECT 
        pd.id, pd.product_specification_name, 
        sd.salesBillId, sd.customerId, sd.total_amount, sd.customer_payable_amount, sd.sales_product_quantity, sd.courier_order_code, 
        cust.name, cust.email, cust.phone_number, cust.address, cust.city, cust.thana, cust.area, cust.zipcode
        FROM products as pd
        INNER JOIN sales_details as sd 
        ON pd.id = sd.productId
        INNER JOIN customers_address as cust
        ON cust.id = sd.customerId
        where sd.salesBillId=${sales_id} and sd.status=1;
      `);
    res.json(sales_product_customer_details);
  } catch (e) {
    console.error(e.message);
    res.send("Server Error");
  }
});

routes.get("/updateSalesDetailsForCourier/:sales_id/:order_id/:courier_partner",
  async (req, res) => {
    const { sales_id, order_id, courier_partner } = req.params;
    console.log("sales_id...", sales_id);
    console.log("order_id...", order_id);
    console.log("courier_partner...", courier_partner);
    try {
      updateSalesDetailsForCourier = await query(`
        UPDATE sales_details 
        SET courier_partner = '${courier_partner}', courier_order_code = '${order_id}'
        WHERE salesBillId = ${sales_id}
      `);
      console.log(updateSalesDetailsForCourier);
      return res.send({ success: true, message: "success" });
    } catch (e) {
      console.error(e.message);
      res.send("Server Error");
    }
  }
);




routes.post('/saveCategory', verifyToken, (req,res)=>{
  jwt.verify(req.token, 'secretkey', (err, authData) => {
    if (err) {
      res.status(403).send({success: false, message: 'jwt expired', status: '403'});
    }
    else {
      try {
        var insertId = '';
        var flag = false;
        var categoryNameForSlug = req.body.categoryName;

        if (req.body.isUpdateClicked == true) {
            var sql_query = "UPDATE category SET category_name = '"+req.body.categoryName+"', description = '"+req.body.categoryDescription+"', parent_category_id = '"+req.body.parentCategory+"', status = '"+req.body.isActive+"' WHERE id = '"+req.body.categoryID+"'";
        }
        else {
            var sql_query = "INSERT INTO category (category_name, description, parent_category_id, status) VALUES ('"+req.body.categoryName+"', '"+req.body.categoryDescription+"', '"+req.body.parentCategory+"', '"+req.body.isActive+"')";
        }

        dbConnection.query(sql_query, function (err, result) {
            if (result) {
                console.log("1 operation performed !");
                insertId = result.insertId;
                flag = true;
            }
            else {
                console.log('Error to inseret at category : ', err);
                return res.send({success: false, server_message: err});
            }
        });

        if (req.body.isUpdateClicked == true) {
            insertId = req.body.categoryID;
        }

        setTimeout(()=> {
          if (flag == true) {            
            let slug = slugify(category_name, id);
            console.log('slug',slug);
            update_sql_query = `update category set slug = ${slug} WHERE id = ${insertId}`;
            dbConnection.query(update_sql_query, function (err, result) {
              if (result) {
                return res.send({success: true, server_message: result, message: 'success'});
              }
              else {
                console.log('Error a the time of category update for slug : ', err);

                return res.send({success: false, error: 'Error has occured at the time of insert data to CATEGORY table', message: 'DB Error'});
              }
            });
          }
          else {
            return res.send({success: false, error: 'Error has occured at the time of insert data to CATEGORY table', message: 'DB Error'});
          }
        }, 700);
      }
      catch (error) {
          if (error) return res.send({success: false, error: 'Error has occured at the time of insert data to CATEGORY table', request : req.body});
      }
    }
  });


  console.log(req);
});




// VERIFY TOKEN
function verifyToken(req, res, next) {
  const secretJwtHeader = req.headers["authorization"]; // GET AUTH VALUE
  // CHECK secretJwt IS NOT UNDEFINED
  if (typeof secretJwtHeader !== undefined) {
    const secretJwt = secretJwtHeader.split(" "); // SPLIT AT THE SPACE
    const secretJwtToekn = secretJwt[1]; // GET TOKEN FROM THE ARRAY
    req.token = secretJwtToekn; // SET THE TOKEN
    next(); // NEXT MIDDLEWARE
  } else {
    res.sendStatus(403);
  }
}


// SLUGIFY
function slugify(str, id){
  str = str.replace(/^\s+|\s+$/g, ''); // trim
    str = str.toLowerCase();
  
    // remove accents, swap ñ for n, etc
    var from = "àáäâèéëêìíïîòóöôùúüûñç·/_,:;";
    var to   = "aaaaeeeeiiiioooouuuunc------";
    for (var i=0, l=from.length ; i<l ; i++) {
        str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
    }

    str = str.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
        .replace(/\s+/g, '-') // collapse whitespace and replace by -
        .replace(/-+/g, '-'); // collapse dashes

    return str+'-'+id;
}


module.exports = routes;
